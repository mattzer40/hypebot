"""
NATA® Bot Manager
=================
Gerencia múltiplas instâncias do bot — uma por cliente.
Cada cliente tem seu próprio token, configurações e pasta isolada.

Uso:
    python manager.py              # inicia todos os clientes ativos
    python manager.py --list       # lista clientes e status
    python manager.py --add        # adiciona novo cliente interativamente
    python manager.py --stop ID    # para a instância de um cliente
"""

import json
import os
import sys
import subprocess
import time
import signal
import shutil
from datetime import date, datetime
from pathlib import Path

# ── Caminhos ─────────────────────────────────────────────────────────────────
CODE_DIR       = Path(__file__).parent
DATA_DIR       = Path(os.environ.get("DATA_DIR", str(CODE_DIR)))
DATA_DIR.mkdir(exist_ok=True)
BOT_SCRIPT     = CODE_DIR / "bot.py"
CUSTOMERS_FILE = DATA_DIR / "customers.json"
CLIENTS_DIR    = DATA_DIR / "clientes"
DEFAULT_AVATAR = CODE_DIR / "default_avatar.png"

CLIENTS_DIR.mkdir(exist_ok=True)

# ── Estado em memória ─────────────────────────────────────────────────────────
_processes: dict[str, subprocess.Popen] = {}


def load_customers() -> list[dict]:
    if not CUSTOMERS_FILE.exists():
        return []
    with open(CUSTOMERS_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_customers(customers: list[dict]) -> None:
    with open(CUSTOMERS_FILE, "w", encoding="utf-8") as f:
        json.dump(customers, f, ensure_ascii=False, indent=2)


def is_expired(customer: dict) -> bool:
    try:
        exp = datetime.strptime(customer.get("expira", ""), "%Y-%m-%d").date()
        return exp < date.today()
    except ValueError:
        return False


def customer_dir(cid: str) -> Path:
    d = CLIENTS_DIR / cid
    d.mkdir(exist_ok=True)
    return d


def start_instance(customer: dict) -> subprocess.Popen | None:
    cid   = customer["id"]
    token = customer.get("token", "").strip()

    if not token or token == "TOKEN_DO_BOT_AQUI":
        print(f"  [AVISO] Cliente '{cid}' sem token configurado — pulando.")
        return None

    if is_expired(customer):
        print(f"  [AVISO] Cliente '{cid}' expirado em {customer.get('expira')} — pulando.")
        return None

    cdir        = customer_dir(cid)
    env_file    = cdir / ".env"
    settings_file = cdir / "bot_settings.json"

    # Cria .env do cliente se não existir
    if not env_file.exists():
        env_file.write_text(f"DISCORD_TOKEN={token}\n", encoding="utf-8")

    # Copia avatar padrão para a pasta do cliente (se existir e ainda não tiver)
    client_avatar = cdir / "default_avatar.png"
    if DEFAULT_AVATAR.exists() and not client_avatar.exists():
        shutil.copy(DEFAULT_AVATAR, client_avatar)

    # Variáveis de ambiente para essa instância
    env = os.environ.copy()
    env["BOT_ENV_FILE"]      = str(env_file)
    env["BOT_SETTINGS_FILE"] = str(settings_file)
    env["BOT_AVATAR_FILE"]   = str(client_avatar)
    guild_id = str(customer.get("guild_id", "") or "").strip()
    if guild_id:
        env["BOT_GUILD_ID"] = guild_id

    log_file = open(cdir / "bot.log", "a", encoding="utf-8")
    log_file.write(f"\n{'='*50}\n[{datetime.now()}] Iniciando instância '{cid}'\n")

    proc = subprocess.Popen(
        [sys.executable, str(BOT_SCRIPT)],
        env=env,
        stdout=log_file,
        stderr=log_file,
        cwd=str(CODE_DIR),
    )
    print(f"  ✅ '{cid}' ({customer.get('nome', '')}) iniciado — PID {proc.pid}")
    return proc


def run_all() -> None:
    customers = load_customers()
    if not customers:
        print("Nenhum cliente cadastrado em customers.json")
        return

    print(f"\n🚀 Iniciando {len(customers)} cliente(s)...\n")
    for c in customers:
        if not c.get("ativo", True):
            print(f"  ⏸️  '{c['id']}' desativado — pulando.")
            continue
        proc = start_instance(c)
        if proc:
            _processes[c["id"]] = proc

    print(f"\n✅ {len(_processes)} instância(s) rodando. Monitorando...\n")

    # Loop de monitoramento — reinicia se travar
    try:
        while True:
            time.sleep(30)
            for cid, proc in list(_processes.items()):
                ret = proc.poll()
                if ret is not None:  # processo morreu
                    print(f"  ⚠️  '{cid}' parou (código {ret}). Reiniciando...")
                    customer = next((c for c in customers if c["id"] == cid), None)
                    if customer and customer.get("ativo") and not is_expired(customer):
                        new_proc = start_instance(customer)
                        if new_proc:
                            _processes[cid] = new_proc
                    else:
                        del _processes[cid]
    except KeyboardInterrupt:
        print("\n\n⛔ Encerrando todas as instâncias...")
        for cid, proc in _processes.items():
            proc.terminate()
            print(f"  🛑 '{cid}' encerrado.")


def cmd_list() -> None:
    customers = load_customers()
    print(f"\n{'ID':<15} {'Nome':<25} {'Ativo':<8} {'Expira':<12} {'Status'}")
    print("-" * 70)
    for c in customers:
        cid    = c["id"]
        nome   = c.get("nome", "")[:24]
        ativo  = "✅" if c.get("ativo") else "⏸️"
        expira = c.get("expira", "—")
        exp    = "⚠️ Expirado" if is_expired(c) else "OK"
        pid    = _processes[cid].pid if cid in _processes else "—"
        print(f"{cid:<15} {nome:<25} {ativo:<8} {expira:<12} {exp} (PID: {pid})")
    print()


def cmd_add() -> None:
    print("\n➕ Adicionar novo cliente\n")
    cid   = input("ID único (sem espaços, ex: cliente2): ").strip()
    nome  = input("Nome do cliente: ").strip()
    token = input("Token do bot Discord: ").strip()
    expira = input("Data de expiração (YYYY-MM-DD, ex: 2026-12-31): ").strip()

    customers = load_customers()
    if any(c["id"] == cid for c in customers):
        print(f"❌ Já existe um cliente com ID '{cid}'.")
        return

    customers.append({
        "id": cid,
        "nome": nome,
        "token": token,
        "ativo": True,
        "expira": expira,
    })
    save_customers(customers)
    print(f"\n✅ Cliente '{cid}' adicionado com sucesso!")
    print(f"   Pasta de dados: clientes/{cid}/")
    print(f"   Para iniciar: python manager.py\n")


def cmd_stop(cid: str) -> None:
    if cid in _processes:
        _processes[cid].terminate()
        del _processes[cid]
        print(f"🛑 Instância '{cid}' encerrada.")
    else:
        print(f"❌ Nenhuma instância ativa com ID '{cid}'.")


if __name__ == "__main__":
    args = sys.argv[1:]

    if "--list" in args:
        cmd_list()
    elif "--add" in args:
        cmd_add()
    elif "--stop" in args:
        idx = args.index("--stop")
        cid = args[idx + 1] if idx + 1 < len(args) else ""
        cmd_stop(cid)
    else:
        run_all()
