#!/usr/bin/env python3
"""
HypeBot Dashboard
===================
Interface web para gerenciar clientes, prefixos e donos do bot.

Instalar dependência:
    pip install flask

Iniciar:
    python dashboard.py

Acesse: http://localhost:5500
"""

import json
import os
import sys
import hashlib
import secrets
import threading
import subprocess as _subprocess
import time as _time
from pathlib import Path
from datetime import date, datetime
from functools import wraps

try:
    from flask import Flask, jsonify, request, render_template_string, redirect, session
except ImportError:
    print("❌ Flask não instalado. Execute: pip install flask")
    sys.exit(1)

# ── Paths ─────────────────────────────────────────────────────────────────────
CODE_DIR       = Path(__file__).parent
DATA_DIR       = Path(os.environ.get("DATA_DIR", str(CODE_DIR)))
DATA_DIR.mkdir(exist_ok=True)
CUSTOMERS_FILE = DATA_DIR / "customers.json"
CONFIG_FILE    = DATA_DIR / "dashboard_config.json"
CLIENTS_DIR    = DATA_DIR / "clientes"
CLIENTS_DIR.mkdir(exist_ok=True)

# ── Seed data from environment variables (first-run migration) ─────────────────
import base64 as _b64_seed
def _seed_file(path: Path, env_var: str):
    """Write file from base64-encoded env var if file doesn't exist yet."""
    if path.exists():
        return
    raw = os.environ.get(env_var, "").strip()
    if not raw:
        return
    try:
        content = _b64_seed.b64decode(raw).decode("utf-8")
        path.write_text(content, encoding="utf-8")
        print(f"[seed] {path.name} restaurado de {env_var}")
    except Exception as e:
        print(f"[seed] Erro ao restaurar {path.name}: {e}")

_seed_file(CONFIG_FILE,    "SEED_CONFIG")
_seed_file(CUSTOMERS_FILE, "SEED_CUSTOMERS")

app = Flask(__name__)


# ── Bot Manager ───────────────────────────────────────────────────────────────

class BotManager:
    """Gerencia subprocessos dos bots Discord, um por cliente."""

    def __init__(self):
        self._procs: dict[str, _subprocess.Popen] = {}
        self._lock  = threading.Lock()

    def start_loop(self):
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()

    def _loop(self):
        _time.sleep(5)  # wait for module to fully initialise
        while True:
            try:
                self._sync()
            except Exception:
                pass
            _time.sleep(30)

    def _sync(self):
        customers = load_customers()
        active = {
            c["id"]: c for c in customers
            if c.get("ativo", True) and not is_expired(c)
                and c.get("token", "").strip() not in ("", "TOKEN_DO_BOT_AQUI")
        }
        with self._lock:
            for cid, c in active.items():
                proc = self._procs.get(cid)
                if proc is None or proc.poll() is not None:
                    p = self._launch(c)
                    if p:
                        self._procs[cid] = p
            for cid in list(self._procs):
                if cid not in active:
                    try:
                        self._procs[cid].terminate()
                    except Exception:
                        pass
                    del self._procs[cid]

    def _launch(self, customer: dict):
        cid   = customer["id"]
        token = customer.get("token", "").strip()
        cdir  = CLIENTS_DIR / cid
        cdir.mkdir(exist_ok=True)
        env_file      = cdir / ".env"
        settings_file = cdir / "bot_settings.json"
        avatar_file   = CODE_DIR / "default_avatar.png"

        if not env_file.exists():
            env_file.write_text(f"DISCORD_TOKEN={token}\n", encoding="utf-8")
        else:
            env_file.write_text(f"DISCORD_TOKEN={token}\n", encoding="utf-8")

        bot_script = CODE_DIR / "bot.py"
        if not bot_script.exists():
            return None

        env = os.environ.copy()
        env["BOT_ENV_FILE"]      = str(env_file)
        env["BOT_SETTINGS_FILE"] = str(settings_file)
        env["BOT_AVATAR_FILE"]   = str(avatar_file)
        env["DATA_DIR"]          = str(DATA_DIR)
        guild_id = str(customer.get("guild_id", "") or "").strip()
        if guild_id:
            env["BOT_GUILD_ID"] = guild_id

        log_path = cdir / "bot.log"
        try:
            log_f = open(log_path, "a", encoding="utf-8")
            log_f.write(f"\n{'='*40}\n[{datetime.now()}] Iniciando bot '{cid}'\n")
            proc = _subprocess.Popen(
                [sys.executable, str(bot_script)],
                env=env, stdout=log_f, stderr=log_f,
                cwd=str(CODE_DIR),
            )
            return proc
        except Exception as e:
            try:
                with open(log_path, "a") as lf:
                    lf.write(f"Erro ao iniciar: {e}\n")
            except Exception:
                pass
            return None

    def status(self) -> dict:
        with self._lock:
            return {
                cid: {"running": proc.poll() is None, "pid": proc.pid}
                for cid, proc in self._procs.items()
            }

    def start_bot(self, cid: str) -> bool:
        customers = load_customers()
        c = next((x for x in customers if x["id"] == cid), None)
        if not c:
            return False
        with self._lock:
            old = self._procs.get(cid)
            if old and old.poll() is None:
                return True  # already running
            p = self._launch(c)
            if p:
                self._procs[cid] = p
                return True
        return False

    def stop_bot(self, cid: str):
        with self._lock:
            proc = self._procs.pop(cid, None)
            if proc:
                try:
                    proc.terminate()
                except Exception:
                    pass

    def restart_bot(self, cid: str) -> bool:
        self.stop_bot(cid)
        _time.sleep(1)
        return self.start_bot(cid)


bot_manager = BotManager()
bot_manager.start_loop()


# ── Config + secret key ───────────────────────────────────────────────────────

def load_config() -> dict:
    if not CONFIG_FILE.exists():
        return {"owners": []}
    with open(CONFIG_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_config(cfg: dict) -> None:
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def _init_secret() -> str:
    cfg = load_config()
    if "secret_key" not in cfg:
        cfg["secret_key"] = secrets.token_hex(32)
        save_config(cfg)
    return cfg["secret_key"]


app.secret_key = _init_secret()


# ── Password helpers ──────────────────────────────────────────────────────────

def _hash(password: str, salt: str | None = None) -> tuple[str, str]:
    if salt is None:
        salt = secrets.token_hex(16)
    h = hashlib.sha256((salt + password).encode("utf-8")).hexdigest()
    return h, salt


def _verify(password: str, stored: str, salt: str) -> bool:
    return _hash(password, salt)[0] == stored


# ── Owner lookup ──────────────────────────────────────────────────────────────

def get_owner(oid: str) -> dict | None:
    return next((o for o in load_config().get("owners", []) if o["id"] == oid), None)


def current_owner() -> dict | None:
    return get_owner(session.get("uid", ""))


# ── Auth decorators ───────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def w(*a, **kw):
        if "uid" not in session:
            if request.path.startswith("/api/"):
                return jsonify({"ok": False, "error": "Não autenticado"}), 401
            return redirect("/login")
        return f(*a, **kw)
    return w


def super_required(f):
    @wraps(f)
    def w(*a, **kw):
        if "uid" not in session:
            return jsonify({"ok": False, "error": "Não autenticado"}), 401
        o = get_owner(session["uid"])
        if not o or o.get("role") != "super":
            return jsonify({"ok": False, "error": "Apenas super admins"}), 403
        return f(*a, **kw)
    return w


# ── Customer helpers ──────────────────────────────────────────────────────────

def load_customers() -> list[dict]:
    if not CUSTOMERS_FILE.exists():
        return []
    with open(CUSTOMERS_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_customers(lst: list[dict]) -> None:
    with open(CUSTOMERS_FILE, "w", encoding="utf-8") as f:
        json.dump(lst, f, ensure_ascii=False, indent=2)


def is_expired(c: dict) -> bool:
    try:
        return datetime.strptime(c.get("expira", ""), "%Y-%m-%d").date() < date.today()
    except ValueError:
        return False


def customer_status(c: dict) -> str:
    if not c.get("ativo", True):
        return "disabled"
    if is_expired(c):
        return "expired"
    return "active"


def load_settings(cid: str) -> dict:
    f = CLIENTS_DIR / cid / "bot_settings.json"
    if f.exists():
        try:
            return json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def save_settings(cid: str, data: dict) -> None:
    d = CLIENTS_DIR / cid
    d.mkdir(exist_ok=True)
    (d / "bot_settings.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def first_prefix(settings: dict) -> str:
    for gs in settings.values():
        if isinstance(gs, dict) and "prefix" in gs:
            return gs["prefix"]
    return "n!"


def read_log(cid: str, n: int = 60) -> str:
    f = CLIENTS_DIR / cid / "bot.log"
    if not f.exists():
        return "(sem log)"
    try:
        lines = f.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-n:])
    except Exception:
        return "(erro ao ler log)"


# ── HTML templates ────────────────────────────────────────────────────────────

_SHARED_CSS = """
<style>
:root{
  --bg:#0f1117;--surface:#1a1d27;--card:#1e2130;--border:#2a2d3e;
  --accent:#7c3aed;--accent2:#a855f7;
  --green:#22c55e;--red:#ef4444;--yellow:#f59e0b;
  --text:#e2e8f0;--muted:#64748b;--input-bg:#11141e;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh}
.logo{font-size:1.8rem;font-weight:800;text-align:center;margin-bottom:4px;
  background:linear-gradient(135deg,#a855f7,#7c3aed);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.form-group{margin-bottom:16px}
label{display:block;font-size:.78rem;font-weight:600;color:var(--muted);
  text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
input,select{width:100%;background:var(--input-bg);border:1px solid var(--border);
  color:var(--text);padding:10px 14px;border-radius:8px;font-size:.9rem;
  font-family:inherit;outline:none;transition:border-color .15s}
input:focus,select:focus{border-color:var(--accent)}
.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);
  color:#ef4444;padding:10px 14px;border-radius:8px;font-size:.85rem;margin-bottom:16px}
select option{background:var(--surface)}
</style>
"""

LOGIN_HTML = """<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><title>HypeBot — Login</title>""" + _SHARED_CSS + """
<style>
body{display:flex;align-items:center;justify-content:center}
.card{background:var(--card);border:1px solid var(--border);border-radius:16px;
  padding:40px;width:100%;max-width:380px}
.sub{text-align:center;color:var(--muted);font-size:.85rem;margin-bottom:28px}
.btn{width:100%;padding:11px;border-radius:8px;border:none;cursor:pointer;
  font-size:.95rem;font-weight:700;background:var(--accent);color:#fff;
  margin-top:8px;transition:opacity .15s}
.btn:hover{opacity:.85}
</style>
</head>
<body>
<div class="card">
  <div class="logo">HypeBot</div>
  <div class="sub">Bot Manager Dashboard</div>
  {% if error %}<div class="err">{{ error }}</div>{% endif %}
  <form method="POST">
    <div class="form-group">
      <label>Usuário</label>
      <input name="username" autocomplete="username" required autofocus>
    </div>
    <div class="form-group">
      <label>Senha</label>
      <input type="password" name="password" autocomplete="current-password" required>
    </div>
    <button type="submit" class="btn">Entrar</button>
  </form>
</div>
</body>
</html>"""

SETUP_HTML = """<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><title>HypeBot — Configuração</title>""" + _SHARED_CSS + """
<style>
body{display:flex;align-items:center;justify-content:center}
.card{background:var(--card);border:1px solid var(--border);border-radius:16px;
  padding:40px;width:100%;max-width:420px}
.sub{text-align:center;color:var(--muted);font-size:.85rem;margin-bottom:6px}
.desc{text-align:center;color:var(--muted);font-size:.8rem;margin-bottom:24px;line-height:1.5}
.btn{width:100%;padding:11px;border-radius:8px;border:none;cursor:pointer;
  font-size:.95rem;font-weight:700;background:var(--accent);color:#fff;
  margin-top:8px;transition:opacity .15s}
.btn:hover{opacity:.85}
</style>
</head>
<body>
<div class="card">
  <div class="logo">HypeBot</div>
  <div class="sub">Configuração Inicial</div>
  <div class="desc">Crie sua conta de administrador principal</div>
  {% if error %}<div class="err">{{ error }}</div>{% endif %}
  <form method="POST">
    <div class="form-group">
      <label>Seu nome</label>
      <input name="nome" required autofocus placeholder="Anderson">
    </div>
    <div class="form-group">
      <label>Nome de usuário</label>
      <input name="username" required pattern="[a-zA-Z0-9_-]+" placeholder="anderson" title="Apenas letras, números, - e _">
    </div>
    <div class="form-group">
      <label>Senha</label>
      <input type="password" name="password" required minlength="6" placeholder="Mínimo 6 caracteres">
    </div>
    <div class="form-group">
      <label>Confirmar senha</label>
      <input type="password" name="confirm" required>
    </div>
    <button type="submit" class="btn">Criar conta de Super Admin</button>
  </form>
</div>
</body>
</html>"""

MAIN_HTML = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>HypeBot Dashboard</title>
<style>
:root{
  --bg:#0f1117;--surface:#1a1d27;--card:#1e2130;--border:#2a2d3e;
  --accent:#7c3aed;--accent2:#a855f7;
  --green:#22c55e;--red:#ef4444;--yellow:#f59e0b;
  --text:#e2e8f0;--muted:#64748b;--input-bg:#11141e;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh}

/* Header */
header{background:var(--surface);border-bottom:1px solid var(--border);padding:12px 28px;
  display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;gap:16px}
.logo{font-size:1.3rem;font-weight:800;flex-shrink:0;
  background:linear-gradient(135deg,#a855f7,#7c3aed);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:1px}

/* Nav tabs */
.nav-tabs{display:flex;gap:4px;flex:1;justify-content:center}
.nav-tab{padding:7px 18px;border-radius:8px;border:none;background:transparent;
  color:var(--muted);cursor:pointer;font-size:.85rem;font-weight:600;transition:all .15s}
.nav-tab:hover{color:var(--text);background:rgba(124,58,237,.15)}
.nav-tab.active{background:var(--accent);color:#fff}

/* User menu */
.user-menu{display:flex;align-items:center;gap:10px;flex-shrink:0}
.avatar{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#a855f7,#7c3aed);
  display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0}
.uname{font-size:.82rem;color:var(--muted);white-space:nowrap}

/* Layout */
main{padding:28px;max-width:1200px;margin:0 auto}

/* Stats */
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:16px;margin-bottom:28px}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px;text-align:center}
.stat-num{font-size:2rem;font-weight:800;
  background:linear-gradient(135deg,#a855f7,#7c3aed);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.stat-label{font-size:.8rem;color:var(--muted);margin-top:4px}

/* Section */
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.section-title{font-size:1.05rem;font-weight:700}

/* Table */
.table-wrap{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden}
table{width:100%;border-collapse:collapse}
th{background:var(--surface);padding:11px 16px;text-align:left;font-size:.73rem;
   color:var(--muted);text-transform:uppercase;letter-spacing:.5px;font-weight:600}
td{padding:13px 16px;border-bottom:1px solid var(--border);font-size:.9rem;vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(124,58,237,.04)}

/* Badges */
.badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:20px;font-size:.73rem;font-weight:700}
.badge::before{content:'';width:6px;height:6px;border-radius:50%}
.badge.active{background:rgba(34,197,94,.15);color:var(--green)}.badge.active::before{background:var(--green)}
.badge.expired{background:rgba(239,68,68,.15);color:var(--red)}.badge.expired::before{background:var(--red)}
.badge.disabled{background:rgba(100,116,139,.15);color:var(--muted)}.badge.disabled::before{background:var(--muted)}
.badge.super{background:rgba(168,85,247,.2);color:#a855f7}.badge.super::before{background:#a855f7}
.badge.admin{background:rgba(100,116,139,.15);color:var(--muted)}.badge.admin::before{background:var(--muted)}
.badge.bot-on{background:rgba(34,197,94,.15);color:var(--green)}.badge.bot-on::before{background:var(--green)}
.badge.bot-off{background:rgba(239,68,68,.15);color:var(--red)}.badge.bot-off::before{background:var(--red)}

/* Buttons */
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:8px;
     border:none;cursor:pointer;font-size:.8rem;font-weight:600;
     transition:opacity .15s,transform .1s;text-decoration:none}
.btn:hover{opacity:.85;transform:translateY(-1px)}.btn:active{transform:translateY(0)}
.btn-primary{background:var(--accent);color:#fff}
.btn-ghost{background:var(--border);color:var(--text)}
.btn-danger{background:rgba(239,68,68,.2);color:var(--red)}
.btn-warn{background:rgba(245,158,11,.15);color:var(--yellow)}
.btn-success{background:rgba(34,197,94,.2);color:var(--green)}
.btn-sm{padding:5px 10px;font-size:.75rem}
.actions{display:flex;gap:6px;flex-wrap:wrap}

/* Prefix chip */
.prefix-chip{display:inline-block;background:var(--input-bg);border:1px solid var(--border);
  color:#a855f7;font-family:monospace;padding:2px 8px;border-radius:6px;font-size:.9rem;font-weight:700}

/* Modal */
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.78);z-index:200;
  align-items:center;justify-content:center;padding:20px}
.overlay.open{display:flex}
.modal{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:26px;
  width:100%;max-width:520px;max-height:90vh;overflow-y:auto;position:relative}
.modal-title{font-size:1.1rem;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px}
.modal-close{position:absolute;top:16px;right:16px;background:var(--border);border:none;
  color:var(--text);width:28px;height:28px;border-radius:50%;cursor:pointer;font-size:1rem;
  display:flex;align-items:center;justify-content:center}
.modal-close:hover{background:var(--accent)}
.form-group{margin-bottom:16px}
.form-label{display:block;font-size:.78rem;font-weight:600;color:var(--muted);
  text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
input,select,textarea{width:100%;background:var(--input-bg);border:1px solid var(--border);
  color:var(--text);padding:10px 14px;border-radius:8px;font-size:.9rem;font-family:inherit;
  transition:border-color .15s;outline:none}
input:focus,select:focus,textarea:focus{border-color:var(--accent)}
select option{background:var(--surface)}
.check-row{display:flex;align-items:center;gap:10px;cursor:pointer}
.check-row input[type=checkbox]{width:18px;height:18px;cursor:pointer;accent-color:var(--accent)}
.check-row span{font-size:.9rem;font-weight:500}

/* Guild prefix table */
.guild-table{width:100%;border-collapse:collapse;font-size:.84rem}
.guild-table th{background:var(--surface);padding:8px 12px;font-size:.7rem}
.guild-table td{padding:8px 12px;border-bottom:1px solid var(--border)}
.guild-table tr:last-child td{border-bottom:none}
.guild-table input{padding:5px 8px;font-size:.84rem}

/* Log */
.log-box{background:var(--input-bg);border:1px solid var(--border);border-radius:8px;padding:12px;
  font-family:monospace;font-size:.72rem;line-height:1.6;max-height:180px;
  overflow-y:auto;color:#94a3b8;white-space:pre-wrap;word-break:break-all}

/* Toast */
.toast-wrap{position:fixed;bottom:24px;right:24px;display:flex;flex-direction:column;gap:8px;z-index:999}
.toast{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px 18px;
  font-size:.85rem;display:flex;align-items:center;gap:10px;animation:slideIn .2s ease;max-width:360px}
.toast.success{border-color:var(--green)}.toast.error{border-color:var(--red)}
@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}

.empty{text-align:center;padding:50px 20px;color:var(--muted)}
.empty-icon{font-size:3rem;margin-bottom:12px}
.divider{border:none;border-top:1px solid var(--border);margin:18px 0}
.sub-label{font-size:.78rem;font-weight:600;color:var(--muted);text-transform:uppercase;
  letter-spacing:.5px;margin-bottom:10px}
.you-tag{font-size:.7rem;background:rgba(124,58,237,.2);color:#a855f7;
  padding:2px 7px;border-radius:10px;font-weight:600;margin-left:6px}

@media(max-width:700px){
  main{padding:14px}header{padding:10px 14px}
  .stats{grid-template-columns:repeat(2,1fr)}
  th,td{padding:10px 10px}
  .nav-tabs{gap:2px}.nav-tab{padding:6px 10px;font-size:.78rem}
  .uname{display:none}
  .col-pfx,.col-exp{display:none}
}
</style>
</head>
<body>

<header>
  <div class="logo">HypeBot</div>
  <div class="nav-tabs">
    <button class="nav-tab active" id="btn-tab-clientes" onclick="showTab('clientes')">🤖 Clientes</button>
    <button class="nav-tab" id="btn-tab-donos" onclick="showTab('donos')" style="display:none">👑 Donos</button>
  </div>
  <div class="user-menu">
    <div class="avatar" id="hdr-avatar">?</div>
    <span class="uname" id="hdr-name"></span>
    <a href="/logout" class="btn btn-ghost btn-sm">Sair</a>
  </div>
</header>

<main>

<!-- ─────────────── TAB: CLIENTES ─────────────── -->
<div id="tab-clientes">
  <div class="stats">
    <div class="stat-card"><div class="stat-num" id="s-total">—</div><div class="stat-label">Total</div></div>
    <div class="stat-card"><div class="stat-num" id="s-active">—</div><div class="stat-label">Ativos</div></div>
    <div class="stat-card"><div class="stat-num" id="s-bots">—</div><div class="stat-label">Bots Online</div></div>
    <div class="stat-card"><div class="stat-num" id="s-expired">—</div><div class="stat-label">Expirados</div></div>
    <div class="stat-card"><div class="stat-num" id="s-disabled">—</div><div class="stat-label">Desativados</div></div>
  </div>
  <div class="section-header">
    <div class="section-title">🤖 Clientes</div>
    <button class="btn btn-primary" onclick="openAdd()">＋ Novo Cliente</button>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>ID / Nome</th><th>Status</th><th class="col-bot">Bot</th><th class="col-pfx">Prefixo</th><th class="col-exp">Expira</th><th>Ações</th></tr></thead>
      <tbody id="tbody"><tr><td colspan="6"><div class="empty"><div class="empty-icon">⏳</div><div>Carregando...</div></div></td></tr></tbody>
    </table>
  </div>
</div>

<!-- ─────────────── TAB: DONOS ─────────────── -->
<div id="tab-donos" style="display:none">
  <div class="section-header">
    <div class="section-title">👑 Donos do Sistema</div>
    <button class="btn btn-primary" onclick="openAddOwner()">＋ Adicionar Dono</button>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Usuário / Nome</th><th>Cargo</th><th>Ações</th></tr></thead>
      <tbody id="owners-body"><tr><td colspan="3"><div class="empty"><div class="empty-icon">⏳</div><div>Carregando...</div></div></td></tr></tbody>
    </table>
  </div>
</div>

</main>

<!-- ─── Modal: Add Customer ─── -->
<div class="overlay" id="m-add">
  <div class="modal">
    <button class="modal-close" onclick="close_('m-add')">✕</button>
    <div class="modal-title">➕ Novo Cliente</div>
    <form onsubmit="submitAdd(event)">
      <div class="form-group"><label class="form-label">ID único (sem espaços)</label>
        <input id="a-id" placeholder="ex: cliente2" required pattern="[a-zA-Z0-9_-]+"></div>
      <div class="form-group"><label class="form-label">Nome do Cliente</label>
        <input id="a-nome" placeholder="ex: João Silva" required></div>
      <div class="form-group"><label class="form-label">Token do Bot Discord</label>
        <input id="a-token" placeholder="MTU..." required oninput="updateInviteLink('a',this.value)"></div>
      <div class="form-group" id="a-invite-wrap" style="display:none">
        <label class="form-label">🔗 Link para adicionar o bot ao servidor</label>
        <div style="display:flex;gap:8px;align-items:center">
          <input id="a-invite-url" readonly style="font-size:.78rem;color:#a855f7;cursor:pointer" onclick="this.select()">
          <a id="a-invite-btn" href="#" target="_blank" rel="noopener"
             class="btn btn-primary btn-sm" style="white-space:nowrap;flex-shrink:0">Adicionar ↗</a>
        </div>
      </div>
      <div class="form-group"><label class="form-label">Prefixo padrão</label>
        <input id="a-prefix" placeholder="n!" maxlength="10" value="n!"></div>
      <div class="form-group"><label class="form-label">Data de Expiração</label>
        <input type="date" id="a-expira" required></div>
      <div class="form-group">
        <label class="check-row"><input type="checkbox" id="a-ativo" checked><span>Ativar imediatamente</span></label>
      </div>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button type="button" class="btn btn-ghost" onclick="close_('m-add')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Adicionar</button>
      </div>
    </form>
  </div>
</div>

<!-- ─── Modal: Edit Customer ─── -->
<div class="overlay" id="m-edit">
  <div class="modal">
    <button class="modal-close" onclick="close_('m-edit')">✕</button>
    <div class="modal-title">✏️ <span id="e-title"></span></div>
    <form onsubmit="submitEdit(event)">
      <input type="hidden" id="e-cid">
      <div class="form-group"><label class="form-label">Nome</label><input id="e-nome" required></div>
      <div class="form-group"><label class="form-label">Token do Bot Discord</label>
        <input id="e-token" required></div>
      <div class="form-group">
        <label class="form-label">Application ID <span style="color:var(--muted);font-weight:400;text-transform:none">(encontre em <a href="https://discord.com/developers/applications" target="_blank" style="color:#a855f7">discord.com/developers</a> → seu app → "Application ID")</span></label>
        <input id="e-appid" placeholder="ex: 1234567890123456789" pattern="[0-9]+" oninput="onAppIdInput('e',this.value)">
      </div>
      <div class="form-group" id="e-invite-wrap" style="display:none">
        <label class="form-label">🔗 Link para adicionar o bot ao servidor</label>
        <div style="display:flex;gap:8px;align-items:center">
          <input id="e-invite-url" readonly style="font-size:.78rem;color:#a855f7;cursor:pointer" onclick="this.select()">
          <a id="e-invite-btn" href="#" target="_blank" rel="noopener"
             class="btn btn-primary btn-sm" style="white-space:nowrap;flex-shrink:0">Adicionar ↗</a>
        </div>
        <div style="margin-top:8px">
          <a id="e-hype-invite-btn" href="#" target="_blank" rel="noopener"
             class="btn btn-sm" style="background:#5865F2;color:#fff;white-space:nowrap;width:100%;text-align:center;display:block">
            🎮 Adicionar ao servidor HYPE (emojis) ↗
          </a>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">ID do Servidor do Cliente <span style="color:var(--muted);font-weight:400;text-transform:none">(o bot só vai responder nesse servidor)</span></label>
        <input id="e-guild-id" placeholder="ex: 1234567890123456789" pattern="[0-9]*" title="Apenas números">
      </div>
      <div class="form-group"><label class="form-label">Data de Expiração</label><input type="date" id="e-expira" required></div>
      <div class="form-group">
        <label class="check-row"><input type="checkbox" id="e-ativo"><span>Ativo</span></label>
      </div>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button type="button" class="btn btn-ghost" onclick="close_('m-edit')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Salvar</button>
      </div>
    </form>
    <hr class="divider">
    <div class="sub-label">🔧 Prefixos por Servidor</div>
    <div id="guild-wrap" style="margin-top:8px">
      <div style="color:var(--muted);font-size:.85rem">Nenhum servidor registrado.<br><small>Aparece após a primeira interação com o bot.</small></div>
    </div>
    <hr class="divider">
    <div class="sub-label">📋 Log Recente</div>
    <div class="log-box" id="e-log">(sem log)</div>
  </div>
</div>

<!-- ─── Modal: Delete Customer ─── -->
<div class="overlay" id="m-del">
  <div class="modal" style="max-width:400px;text-align:center">
    <button class="modal-close" onclick="close_('m-del')">✕</button>
    <div style="font-size:2.5rem;margin-bottom:12px">⚠️</div>
    <div class="modal-title" style="justify-content:center">Remover Cliente</div>
    <p style="color:var(--muted);font-size:.9rem;margin-bottom:20px">
      Remover <strong id="del-name"></strong>?<br>
      <small>Os arquivos em <code>clientes/</code> serão mantidos.</small>
    </p>
    <input type="hidden" id="del-cid">
    <div style="display:flex;gap:10px;justify-content:center">
      <button class="btn btn-ghost" onclick="close_('m-del')">Cancelar</button>
      <button class="btn btn-danger" onclick="doDelete()">Remover</button>
    </div>
  </div>
</div>

<!-- ─── Modal: Add Owner ─── -->
<div class="overlay" id="m-add-owner">
  <div class="modal">
    <button class="modal-close" onclick="close_('m-add-owner')">✕</button>
    <div class="modal-title">👑 Adicionar Dono</div>
    <form onsubmit="submitAddOwner(event)">
      <div class="form-group"><label class="form-label">Nome de exibição</label>
        <input id="ao-nome" placeholder="ex: João Parceiro" required></div>
      <div class="form-group"><label class="form-label">Nome de usuário (login)</label>
        <input id="ao-id" placeholder="ex: joao" required pattern="[a-zA-Z0-9_-]+" title="Apenas letras, números, - e _"></div>
      <div class="form-group"><label class="form-label">Senha</label>
        <input type="password" id="ao-pwd" required minlength="6" placeholder="Mínimo 6 caracteres"></div>
      <div class="form-group"><label class="form-label">Confirmar senha</label>
        <input type="password" id="ao-confirm" required></div>
      <div class="form-group"><label class="form-label">Cargo</label>
        <select id="ao-role">
          <option value="admin">👤 Admin — gerencia clientes</option>
          <option value="super">🔰 Super Admin — gerencia tudo</option>
        </select>
      </div>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button type="button" class="btn btn-ghost" onclick="close_('m-add-owner')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Adicionar</button>
      </div>
    </form>
  </div>
</div>

<!-- ─── Modal: Change Password ─── -->
<div class="overlay" id="m-pwd">
  <div class="modal" style="max-width:420px">
    <button class="modal-close" onclick="close_('m-pwd')">✕</button>
    <div class="modal-title">🔑 Alterar Senha — <span id="pwd-name"></span></div>
    <form onsubmit="submitPwd(event)">
      <input type="hidden" id="pwd-oid">
      <div class="form-group" id="pwd-old-wrap">
        <label class="form-label">Senha atual</label>
        <input type="password" id="pwd-old" placeholder="Sua senha atual">
      </div>
      <div class="form-group"><label class="form-label">Nova senha</label>
        <input type="password" id="pwd-new" required minlength="6" placeholder="Mínimo 6 caracteres"></div>
      <div class="form-group"><label class="form-label">Confirmar nova senha</label>
        <input type="password" id="pwd-confirm" required></div>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button type="button" class="btn btn-ghost" onclick="close_('m-pwd')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Alterar Senha</button>
      </div>
    </form>
  </div>
</div>

<!-- ─── Modal: Delete Owner ─── -->
<div class="overlay" id="m-del-owner">
  <div class="modal" style="max-width:400px;text-align:center">
    <button class="modal-close" onclick="close_('m-del-owner')">✕</button>
    <div style="font-size:2.5rem;margin-bottom:12px">⚠️</div>
    <div class="modal-title" style="justify-content:center">Remover Dono</div>
    <p style="color:var(--muted);font-size:.9rem;margin-bottom:20px">
      Remover <strong id="del-owner-name"></strong> do sistema?
    </p>
    <input type="hidden" id="del-owner-id">
    <div style="display:flex;gap:10px;justify-content:center">
      <button class="btn btn-ghost" onclick="close_('m-del-owner')">Cancelar</button>
      <button class="btn btn-danger" onclick="doDeleteOwner()">Remover</button>
    </div>
  </div>
</div>

<!-- Toasts -->
<div class="toast-wrap" id="toasts"></div>

<script>
/* inject current user from server */
const ME = {{ me | tojson }};
const IS_SUPER = ME.role === 'super';

/* init header */
document.getElementById('hdr-avatar').textContent = (ME.nome||'?')[0].toUpperCase();
document.getElementById('hdr-name').textContent   = ME.nome;
if (IS_SUPER) document.getElementById('btn-tab-donos').style.display = '';

/* ── Tabs ── */
function showTab(name) {
  ['clientes','donos'].forEach(t => {
    document.getElementById('tab-'+t).style.display      = t===name ? '' : 'none';
    document.getElementById('btn-tab-'+t).classList.toggle('active', t===name);
  });
  if (name === 'donos') loadOwners();
}

/* ── Modals ── */
function open_(id)  { document.getElementById(id).classList.add('open'); }
function close_(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.overlay').forEach(el =>
  el.addEventListener('click', e => { if(e.target===el) close_(el.id); })
);

/* ═══════════════════════════════════════════════════
   CUSTOMERS
═══════════════════════════════════════════════════ */
let _list = [];

async function load() {
  try {
    const r = await fetch('/api/customers');
    if (r.status === 401) { location.href='/login'; return; }
    _list = await r.json();
    renderStats(); renderTable();
  } catch(e) { toast('❌ Erro ao carregar','error'); }
}

function renderStats() {
  document.getElementById('s-total').textContent    = _list.length;
  document.getElementById('s-active').textContent   = _list.filter(c=>c.status==='active').length;
  document.getElementById('s-bots').textContent     = _list.filter(c=>c.bot_running).length;
  document.getElementById('s-expired').textContent  = _list.filter(c=>c.status==='expired').length;
  document.getElementById('s-disabled').textContent = _list.filter(c=>c.status==='disabled').length;
}

function renderTable() {
  const tbody = document.getElementById('tbody');
  if (!_list.length) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">
      <div class="empty-icon">🤖</div>
      <div style="margin-bottom:16px">Nenhum cliente cadastrado</div>
      <button class="btn btn-primary" onclick="openAdd()">Adicionar primeiro cliente</button>
    </div></td></tr>`;
    return;
  }
  const lb = {active:'Ativo',expired:'Expirado',disabled:'Desativado'};
  tbody.innerHTML = _list.map(c => {
    const canRun = c.status === 'active';
    const botBadge = !canRun
      ? '<span class="badge disabled">⏸️ Inativo</span>'
      : c.bot_running
        ? '<span class="badge bot-on">🟢 Online</span>'
        : '<span class="badge bot-off">🔴 Offline</span>';
    const botBtns = !canRun ? '' : c.bot_running
      ? `<button class="btn btn-warn btn-sm" title="Reiniciar bot" onclick="botAction('${esc(c.id)}','restart')">🔄</button>
         <button class="btn btn-danger btn-sm" title="Parar bot" onclick="botAction('${esc(c.id)}','stop')">⏹</button>`
      : `<button class="btn btn-success btn-sm" onclick="botAction('${esc(c.id)}','start')">▶ Iniciar</button>`;
    return `
    <tr>
      <td><div style="font-weight:700">${esc(c.id)}</div>
          <div style="font-size:.78rem;color:var(--muted)">${esc(c.nome||'')}</div></td>
      <td><span class="badge ${c.status}">${lb[c.status]||c.status}</span></td>
      <td class="col-bot">${botBadge}</td>
      <td class="col-pfx"><span class="prefix-chip">${esc(c.prefix||'n!')}</span></td>
      <td class="col-exp" style="color:var(--muted);font-size:.85rem">${esc(c.expira||'—')}</td>
      <td><div class="actions">
        <button class="btn btn-ghost btn-sm" onclick="openEdit('${esc(c.id)}')">✏️</button>
        ${botBtns}
        <button class="btn btn-danger btn-sm" onclick="openDel('${esc(c.id)}','${esc(c.nome||c.id)}')">🗑️</button>
      </div></td>
    </tr>`;
  }).join('');
}

async function botAction(cid, action) {
  const msgs = {start:'▶ Bot iniciado!', stop:'⏹ Bot parado', restart:'🔄 Bot reiniciado!'};
  const r = await api('POST', `/api/customers/${cid}/bot/${action}`);
  if (r.ok) { toast(msgs[action]||'✅ OK','success'); load(); }
  else toast('❌ '+(r.error||'Erro'),'error');
}

/* Add */
function openAdd() {
  ['a-id','a-nome','a-token'].forEach(id => document.getElementById(id).value='');
  document.getElementById('a-prefix').value = 'n!';
  document.getElementById('a-ativo').checked = true;
  document.getElementById('a-invite-wrap').style.display = 'none';
  const d = new Date(); d.setFullYear(d.getFullYear()+1);
  document.getElementById('a-expira').value = d.toISOString().split('T')[0];
  open_('m-add');
}

async function submitAdd(e) {
  e.preventDefault();
  const r = await api('POST','/api/customers',{
    id:   document.getElementById('a-id').value.trim(),
    nome: document.getElementById('a-nome').value.trim(),
    token:document.getElementById('a-token').value.trim(),
    default_prefix: document.getElementById('a-prefix').value.trim()||'n!',
    expira:document.getElementById('a-expira').value,
    ativo: document.getElementById('a-ativo').checked,
  });
  if(r.ok){toast('✅ Cliente adicionado!','success');close_('m-add');load();}
  else toast('❌ '+(r.error||'Erro'),'error');
}

/* Edit */
async function openEdit(cid) {
  const c = _list.find(x=>x.id===cid); if(!c) return;
  document.getElementById('e-cid').value   = cid;
  document.getElementById('e-title').textContent = cid;
  document.getElementById('e-nome').value  = c.nome||'';
  document.getElementById('e-token').value = c.token||'';
  document.getElementById('e-appid').value    = c.app_id||'';
  document.getElementById('e-guild-id').value = c.guild_id||'';
  document.getElementById('e-expira').value   = c.expira||'';
  document.getElementById('e-ativo').checked  = c.ativo!==false;
  // Reset invite link while loading
  document.getElementById('e-invite-wrap').style.display = 'none';
  document.getElementById('e-log').textContent   = '⏳ carregando...';
  document.getElementById('guild-wrap').innerHTML = '⏳ carregando...';
  open_('m-edit');
  // Show invite link if app_id already saved, otherwise try server endpoint
  if (c.app_id) {
    showInviteLink('e', c.app_id);
  } else {
    fetch('/api/customers/'+cid+'/bot/invite').then(r=>r.json()).then(d=>{
      if (d.ok && d.url) {
        document.getElementById('e-invite-url').value = d.url;
        document.getElementById('e-invite-btn').href  = d.url;
        document.getElementById('e-invite-wrap').style.display = '';
        // Auto-fill the app_id field too
        if (d.app_id) document.getElementById('e-appid').value = d.app_id;
      }
    }).catch(()=>{});
  }
  fetch('/api/customers/'+cid+'/log').then(r=>r.json()).then(d=>{
    document.getElementById('e-log').textContent = d.log||'(sem log)';
  });
  fetch('/api/customers/'+cid+'/settings').then(r=>r.json()).then(d=>renderGuilds(cid,d.settings||{}));
}

function renderGuilds(cid, settings) {
  const wrap = document.getElementById('guild-wrap');
  const entries = Object.entries(settings);
  if(!entries.length){
    wrap.innerHTML='<div style="color:var(--muted);font-size:.85rem">Nenhum servidor registrado ainda.<br><small>Aparece após a primeira interação com o bot.</small></div>';
    return;
  }
  let h='<table class="guild-table"><thead><tr><th>Servidor (ID)</th><th>Prefixo</th><th></th></tr></thead><tbody>';
  for(const[gid,gs] of entries){
    const p=(typeof gs==='object'&&gs.prefix)?gs.prefix:'n!';
    h+=`<tr>
      <td style="font-family:monospace;font-size:.78rem">${esc(gid)}</td>
      <td><input id="pfx-${esc(gid)}" value="${esc(p)}" style="max-width:90px" maxlength="10"></td>
      <td><button class="btn btn-primary btn-sm" onclick="savePfx('${esc(cid)}','${esc(gid)}')">Salvar</button></td>
    </tr>`;
  }
  h+='</tbody></table>';
  wrap.innerHTML=h;
}

async function savePfx(cid,gid){
  const el=document.getElementById('pfx-'+gid); if(!el) return;
  const prefix=el.value.trim();
  if(!prefix||prefix.length>10||prefix.includes(' ')){toast('❌ Prefixo inválido','error');return;}
  const r=await api('POST',`/api/customers/${cid}/prefix`,{guild_id:gid,prefix});
  if(r.ok){toast(`✅ Prefixo atualizado!`,'success');load();}
  else toast('❌ '+(r.error||'Erro'),'error');
}

async function submitEdit(e){
  e.preventDefault();
  const cid=document.getElementById('e-cid').value;
  const r=await api('PUT','/api/customers/'+cid,{
    nome:     document.getElementById('e-nome').value.trim(),
    token:    document.getElementById('e-token').value.trim(),
    app_id:   document.getElementById('e-appid').value.trim(),
    guild_id: document.getElementById('e-guild-id').value.trim(),
    expira:   document.getElementById('e-expira').value,
    ativo:    document.getElementById('e-ativo').checked,
  });
  if(r.ok){toast('✅ Salvo!','success');close_('m-edit');load();}
  else toast('❌ '+(r.error||'Erro'),'error');
}

/* Delete customer */
function openDel(cid,nome){
  document.getElementById('del-cid').value=cid;
  document.getElementById('del-name').textContent=nome;
  open_('m-del');
}
async function doDelete(){
  const cid=document.getElementById('del-cid').value;
  const r=await api('DELETE','/api/customers/'+cid);
  if(r.ok){toast('✅ Removido','success');close_('m-del');load();}
  else toast('❌ '+(r.error||'Erro'),'error');
}

/* ═══════════════════════════════════════════════════
   OWNERS
═══════════════════════════════════════════════════ */
let _owners = [];

async function loadOwners() {
  const r = await fetch('/api/owners');
  if(!r.ok){ return; }
  _owners = await r.json();
  renderOwners();
}

function renderOwners() {
  const tbody = document.getElementById('owners-body');
  if(!_owners.length){
    tbody.innerHTML='<tr><td colspan="3"><div class="empty"><div class="empty-icon">👑</div><div>Nenhum dono cadastrado</div></div></td></tr>';
    return;
  }
  tbody.innerHTML = _owners.map(o => {
    const isMe = o.id === ME.id;
    const roleBadge = o.role==='super'
      ? '<span class="badge super">🔰 Super Admin</span>'
      : '<span class="badge admin">👤 Admin</span>';
    const youTag = isMe ? '<span class="you-tag">você</span>' : '';
    const canRemove = IS_SUPER && !isMe;
    return `<tr>
      <td>
        <div style="font-weight:700">${esc(o.id)}${youTag}</div>
        <div style="font-size:.78rem;color:var(--muted)">${esc(o.nome||'')}</div>
      </td>
      <td>${roleBadge}</td>
      <td><div class="actions">
        <button class="btn btn-warn btn-sm" onclick="openPwd('${esc(o.id)}','${esc(o.nome||o.id)}',${isMe})">🔑 Senha</button>
        ${canRemove ? `<button class="btn btn-danger btn-sm" onclick="openDelOwner('${esc(o.id)}','${esc(o.nome||o.id)}')">🗑️</button>` : ''}
      </div></td>
    </tr>`;
  }).join('');
}

/* Add owner */
function openAddOwner(){
  ['ao-nome','ao-id','ao-pwd','ao-confirm'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('ao-role').value='admin';
  open_('m-add-owner');
}

async function submitAddOwner(e){
  e.preventDefault();
  const pwd=document.getElementById('ao-pwd').value;
  const confirm=document.getElementById('ao-confirm').value;
  if(pwd!==confirm){toast('❌ As senhas não coincidem','error');return;}
  const r=await api('POST','/api/owners',{
    id:   document.getElementById('ao-id').value.trim(),
    nome: document.getElementById('ao-nome').value.trim(),
    password: pwd,
    role: document.getElementById('ao-role').value,
  });
  if(r.ok){toast('✅ Dono adicionado!','success');close_('m-add-owner');loadOwners();}
  else toast('❌ '+(r.error||'Erro'),'error');
}

/* Change password */
function openPwd(oid, nome, isMe){
  document.getElementById('pwd-oid').value=oid;
  document.getElementById('pwd-name').textContent=nome;
  document.getElementById('pwd-old').value='';
  document.getElementById('pwd-new').value='';
  document.getElementById('pwd-confirm').value='';
  /* show old-password field only when changing own password */
  document.getElementById('pwd-old-wrap').style.display = isMe ? '' : 'none';
  document.getElementById('pwd-old').required = isMe;
  open_('m-pwd');
}

async function submitPwd(e){
  e.preventDefault();
  const oid=document.getElementById('pwd-oid').value;
  const isMe=oid===ME.id;
  const newPwd=document.getElementById('pwd-new').value;
  const confirm=document.getElementById('pwd-confirm').value;
  if(newPwd!==confirm){toast('❌ As senhas não coincidem','error');return;}
  const body={password:newPwd};
  if(isMe) body.old_password=document.getElementById('pwd-old').value;
  const r=await api('PUT','/api/owners/'+oid+'/password',body);
  if(r.ok){toast('✅ Senha alterada!','success');close_('m-pwd');}
  else toast('❌ '+(r.error||'Erro'),'error');
}

/* Delete owner */
function openDelOwner(oid,nome){
  document.getElementById('del-owner-id').value=oid;
  document.getElementById('del-owner-name').textContent=nome;
  open_('m-del-owner');
}
async function doDeleteOwner(){
  const oid=document.getElementById('del-owner-id').value;
  const r=await api('DELETE','/api/owners/'+oid);
  if(r.ok){toast('✅ Dono removido','success');close_('m-del-owner');loadOwners();}
  else toast('❌ '+(r.error||'Erro'),'error');
}

/* ── Helpers ── */
async function api(method,url,body){
  try{
    const opts={method,headers:{'Content-Type':'application/json'}};
    if(body) opts.body=JSON.stringify(body);
    const r=await fetch(url,opts);
    if(r.status===401){location.href='/login';return{ok:false};}
    return await r.json();
  }catch(e){return{ok:false,error:String(e)};}
}

function toast(msg,type='success'){
  const w=document.getElementById('toasts');
  const el=document.createElement('div');
  el.className='toast '+type;el.textContent=msg;
  w.appendChild(el);setTimeout(()=>el.remove(),3500);
}

/* ── Invite link helpers ── */
const HYPE_GUILD_ID = '1506247261011578890';

function buildInviteUrl(appId) {
  return `https://discord.com/oauth2/authorize?client_id=${appId}&permissions=8&scope=bot%20applications.commands`;
}

function buildHypeInviteUrl(appId) {
  return `https://discord.com/oauth2/authorize?client_id=${appId}&permissions=8&scope=bot%20applications.commands&guild_id=${HYPE_GUILD_ID}&disable_guild_select=true`;
}

function showInviteLink(prefix, appId) {
  const wrap = document.getElementById(prefix+'-invite-wrap');
  if (!appId || !/^\\d{10,}$/.test(appId)) { wrap.style.display='none'; return; }
  const url     = buildInviteUrl(appId);
  const hypeUrl = buildHypeInviteUrl(appId);
  document.getElementById(prefix+'-invite-url').value = url;
  document.getElementById(prefix+'-invite-btn').href  = url;
  // Botão HYPE só existe no modal de edição (prefixo 'e')
  const hypeBtn = document.getElementById(prefix+'-hype-invite-btn');
  if (hypeBtn) hypeBtn.href = hypeUrl;
  wrap.style.display = '';
}

function onAppIdInput(prefix, val) {
  showInviteLink(prefix, val.trim());
}

// kept for backwards compat (add modal token field still calls this)
function updateInviteLink(prefix, token) {
  if (!token) return;
  try {
    const b64 = token.split('.')[0].replace(/-/g,'+').replace(/_/g,'/');
    const pad = (4 - b64.length%4)%4;
    const clientId = atob(b64 + '='.repeat(pad));
    showInviteLink(prefix, clientId);
  } catch(e) {}
}

function esc(s){
  if(s==null) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

/* ── Init ── */
load();
setInterval(load, 30000);
</script>
</body>
</html>"""


# ── Auth routes ───────────────────────────────────────────────────────────────

@app.route("/setup", methods=["GET", "POST"])
def setup():
    cfg = load_config()
    if cfg.get("owners"):
        return redirect("/")
    error = None
    if request.method == "POST":
        nome     = request.form.get("nome", "").strip()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm  = request.form.get("confirm", "")
        if not nome or not username or not password:
            error = "Preencha todos os campos."
        elif password != confirm:
            error = "As senhas não coincidem."
        elif len(password) < 6:
            error = "Senha deve ter pelo menos 6 caracteres."
        else:
            h, salt = _hash(password)
            cfg["owners"] = [{
                "id":     username,
                "nome":   nome,
                "hash":   h,
                "salt":   salt,
                "role":   "super",
            }]
            save_config(cfg)
            session["uid"] = username
            return redirect("/")
    return render_template_string(SETUP_HTML, error=error)


@app.route("/login", methods=["GET", "POST"])
def login():
    cfg = load_config()
    if not cfg.get("owners"):
        return redirect("/setup")
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        owner = next((o for o in cfg["owners"] if o["id"] == username), None)
        if owner and _verify(password, owner["hash"], owner["salt"]):
            session["uid"] = username
            return redirect("/")
        error = "Usuário ou senha incorretos."
    return render_template_string(LOGIN_HTML, error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")


@app.route("/")
@login_required
def index():
    owner = get_owner(session["uid"])
    me = {"id": owner["id"], "nome": owner["nome"], "role": owner.get("role", "admin")}
    return render_template_string(MAIN_HTML, me=me)


# ── Customer API ──────────────────────────────────────────────────────────────

@app.route("/api/customers", methods=["GET"])
@login_required
def api_list():
    customers  = load_customers()
    bot_status = bot_manager.status()
    result = []
    for c in customers:
        settings = load_settings(c["id"])
        bs = bot_status.get(c["id"], {})
        result.append({
            **c,
            "status":      customer_status(c),
            "prefix":      first_prefix(settings),
            "bot_running": bs.get("running", False),
            "bot_pid":     bs.get("pid"),
        })
    return jsonify(result)


@app.route("/api/customers", methods=["POST"])
@login_required
def api_add():
    data = request.get_json(force=True) or {}
    cid  = data.get("id", "").strip()
    if not cid:
        return jsonify({"ok": False, "error": "ID obrigatório"}), 400
    customers = load_customers()
    if any(c["id"] == cid for c in customers):
        return jsonify({"ok": False, "error": f"ID '{cid}' já existe"}), 400
    default_prefix = data.get("default_prefix", "n!").strip() or "n!"
    save_settings(cid, {"default": {"prefix": default_prefix}})
    new_customer = {
        "id":     cid,
        "nome":   data.get("nome", ""),
        "token":  data.get("token", ""),
        "ativo":  data.get("ativo", True),
        "expira": data.get("expira", ""),
    }
    customers.append(new_customer)
    save_customers(customers)
    # Auto-start the bot right away if the customer is active and has a real token
    token = new_customer["token"].strip()
    if new_customer["ativo"] and token and token != "TOKEN_DO_BOT_AQUI":
        bot_manager.start_bot(cid)
    return jsonify({"ok": True})


@app.route("/api/customers/<cid>", methods=["PUT"])
@login_required
def api_update(cid):
    data = request.get_json(force=True) or {}
    customers = load_customers()
    for c in customers:
        if c["id"] == cid:
            old_token = c.get("token", "")
            c["nome"]   = data.get("nome",   c.get("nome", ""))
            c["token"]  = data.get("token",  c.get("token", ""))
            c["expira"] = data.get("expira", c.get("expira", ""))
            c["ativo"]  = data.get("ativo",  c.get("ativo", True))
            if "app_id" in data:
                c["app_id"] = data["app_id"].strip()
            if "guild_id" in data:
                c["guild_id"] = data["guild_id"].strip()
            save_customers(customers)
            token = c["token"].strip()
            # Restart immediately with new settings if the customer should be running
            if c.get("ativo", True) and token and token != "TOKEN_DO_BOT_AQUI" and not is_expired(c):
                bot_manager.restart_bot(cid)
            else:
                bot_manager.stop_bot(cid)
            return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Cliente não encontrado"}), 404


@app.route("/api/customers/<cid>", methods=["DELETE"])
@login_required
def api_delete(cid):
    customers = load_customers()
    new_list = [c for c in customers if c["id"] != cid]
    if len(new_list) == len(customers):
        return jsonify({"ok": False, "error": "Cliente não encontrado"}), 404
    save_customers(new_list)
    bot_manager.stop_bot(cid)  # kill the process if running
    return jsonify({"ok": True})


@app.route("/api/customers/<cid>/settings", methods=["GET"])
@login_required
def api_settings(cid):
    return jsonify({"ok": True, "settings": load_settings(cid)})


@app.route("/api/admin/auto-guild-ids", methods=["POST"])
def api_auto_guild_ids():
    """Detecta e salva o guild_id de cada cliente via Discord API.
    Auth: Bearer {secret_key}"""
    import urllib.request as _ureq
    import urllib.error  as _uerr

    # Autenticação via secret key
    auth = request.headers.get("Authorization", "")
    cfg  = load_config()
    expected = "Bearer " + cfg.get("secret_key", "")
    if auth != expected:
        return jsonify({"ok": False, "error": "Não autorizado"}), 401

    EMOJI_GUILD = 1506247261011578890
    DISCORD     = "https://discord.com/api/v10"
    results     = []

    customers = load_customers()
    for c in customers:
        cid   = c["id"]
        token = c.get("token", "").strip()
        nome  = c.get("nome", cid)

        if not token or "TOKEN_DO_BOT" in token:
            results.append({"cid": cid, "nome": nome, "status": "sem_token"})
            continue

        if c.get("guild_id"):
            results.append({"cid": cid, "nome": nome, "status": "ja_configurado", "guild_id": c["guild_id"]})
            continue

        # Chama Discord API
        try:
            req = _ureq.Request(
                DISCORD + "/users/@me/guilds",
                headers={"Authorization": f"Bot {token}"},
            )
            with _ureq.urlopen(req, timeout=8) as r:
                guilds = json.loads(r.read())
        except _uerr.HTTPError as e:
            results.append({"cid": cid, "nome": nome, "status": f"discord_erro_{e.code}"})
            continue
        except Exception as e:
            results.append({"cid": cid, "nome": nome, "status": f"erro_{str(e)[:50]}"})
            continue

        valid = [g for g in guilds if int(g["id"]) != EMOJI_GUILD]
        if not valid:
            results.append({"cid": cid, "nome": nome, "status": "sem_servidor_valido"})
            continue

        # Pega o primeiro servidor válido (ou o que tiver mais membros)
        chosen = max(valid, key=lambda g: g.get("approximate_member_count", 0)) if len(valid) > 1 else valid[0]
        c["guild_id"] = chosen["id"]
        results.append({
            "cid": cid, "nome": nome,
            "status": "ok",
            "guild_id": chosen["id"],
            "guild_name": chosen.get("name", "?"),
        })

    save_customers(customers)
    # Reinicia os bots para aplicar restrição
    for c in customers:
        if c.get("guild_id") and c.get("ativo"):
            bot_manager.restart_bot(c["id"])

    return jsonify({"ok": True, "results": results})


@app.route("/api/customers/<cid>/prefix", methods=["POST"])
@login_required
def api_set_prefix(cid):
    data     = request.get_json(force=True) or {}
    guild_id = str(data.get("guild_id", "")).strip()
    prefix   = str(data.get("prefix",   "")).strip()
    if not prefix or len(prefix) > 10 or " " in prefix:
        return jsonify({"ok": False, "error": "Prefixo inválido"}), 400
    if not guild_id:
        return jsonify({"ok": False, "error": "guild_id obrigatório"}), 400
    settings = load_settings(cid)
    if guild_id in settings and isinstance(settings[guild_id], dict):
        settings[guild_id]["prefix"] = prefix
    else:
        settings[guild_id] = {"prefix": prefix}
    save_settings(cid, settings)
    return jsonify({"ok": True})


@app.route("/api/customers/<cid>/log", methods=["GET"])
@login_required
def api_log(cid):
    return jsonify({"ok": True, "log": read_log(cid)})




@app.route("/api/customers/<cid>/bot/invite", methods=["GET"])
@login_required
def api_bot_invite(cid):
    """Retorna o link de convite usando app_id salvo ou extraído do token."""
    import base64 as _b64

    customers = load_customers()
    c = next((x for x in customers if x["id"] == cid), None)
    if not c:
        return jsonify({"ok": False, "error": "Cliente não encontrado"}), 404

    # Prefer manually saved app_id
    app_id = c.get("app_id", "").strip()

    # Fallback: decode from token first segment
    if not app_id:
        token = c.get("token", "").strip()
        if token and token != "TOKEN_DO_BOT_AQUI":
            try:
                part = token.split(".")[0]
                pad = (4 - len(part) % 4) % 4
                decoded = _b64.b64decode(part + "=" * pad).decode("utf-8", errors="replace").strip()
                if decoded.isdigit() and len(decoded) >= 10:
                    app_id = decoded
            except Exception:
                pass

    if not app_id:
        return jsonify({"ok": False, "error": "Application ID não encontrado. Preencha o campo no formulário."}), 400

    url = (
        f"https://discord.com/oauth2/authorize"
        f"?client_id={app_id}&permissions=8&scope=bot%20applications.commands"
    )
    return jsonify({"ok": True, "app_id": app_id, "url": url})


# ── Bot Control API ───────────────────────────────────────────────────────────

@app.route("/api/customers/<cid>/bot/start", methods=["POST"])
@login_required
def api_bot_start(cid):
    ok = bot_manager.start_bot(cid)
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Não foi possível iniciar o bot. Verifique o token e se o bot.py existe."}), 400


@app.route("/api/customers/<cid>/bot/stop", methods=["POST"])
@login_required
def api_bot_stop(cid):
    bot_manager.stop_bot(cid)
    return jsonify({"ok": True})


@app.route("/api/customers/<cid>/bot/restart", methods=["POST"])
@login_required
def api_bot_restart(cid):
    ok = bot_manager.restart_bot(cid)
    if ok:
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Não foi possível reiniciar o bot."}), 400


# ── Owners API ────────────────────────────────────────────────────────────────

@app.route("/api/owners", methods=["GET"])
@super_required
def api_owners_list():
    cfg = load_config()
    # Return owners without password data
    result = [
        {"id": o["id"], "nome": o["nome"], "role": o.get("role", "admin")}
        for o in cfg.get("owners", [])
    ]
    return jsonify(result)


@app.route("/api/owners", methods=["POST"])
@super_required
def api_owners_add():
    data     = request.get_json(force=True) or {}
    oid      = data.get("id", "").strip()
    nome     = data.get("nome", "").strip()
    password = data.get("password", "")
    role     = data.get("role", "admin")

    if not oid or not nome or not password:
        return jsonify({"ok": False, "error": "ID, nome e senha são obrigatórios"}), 400
    if len(password) < 6:
        return jsonify({"ok": False, "error": "Senha deve ter pelo menos 6 caracteres"}), 400
    if role not in ("admin", "super"):
        role = "admin"

    cfg = load_config()
    if any(o["id"] == oid for o in cfg.get("owners", [])):
        return jsonify({"ok": False, "error": f"Usuário '{oid}' já existe"}), 400

    h, salt = _hash(password)
    cfg.setdefault("owners", []).append({
        "id":   oid,
        "nome": nome,
        "hash": h,
        "salt": salt,
        "role": role,
    })
    save_config(cfg)
    return jsonify({"ok": True})


@app.route("/api/owners/<oid>", methods=["DELETE"])
@super_required
def api_owners_delete(oid):
    if oid == session.get("uid"):
        return jsonify({"ok": False, "error": "Você não pode remover sua própria conta"}), 400
    cfg = load_config()
    owners = cfg.get("owners", [])
    new_owners = [o for o in owners if o["id"] != oid]
    if len(new_owners) == len(owners):
        return jsonify({"ok": False, "error": "Usuário não encontrado"}), 404
    # Prevent removing the last super admin
    supers = [o for o in new_owners if o.get("role") == "super"]
    if not supers:
        return jsonify({"ok": False, "error": "Não é possível remover o único Super Admin"}), 400
    cfg["owners"] = new_owners
    save_config(cfg)
    return jsonify({"ok": True})


@app.route("/api/owners/<oid>/password", methods=["PUT"])
@login_required
def api_owners_password(oid):
    data        = request.get_json(force=True) or {}
    new_password = data.get("password", "")
    old_password = data.get("old_password", "")
    requester   = get_owner(session["uid"])

    if len(new_password) < 6:
        return jsonify({"ok": False, "error": "Senha deve ter pelo menos 6 caracteres"}), 400

    target = get_owner(oid)
    if not target:
        return jsonify({"ok": False, "error": "Usuário não encontrado"}), 404

    is_self  = (oid == session["uid"])
    is_super = requester and requester.get("role") == "super"

    # Must be self or super admin to change password
    if not is_self and not is_super:
        return jsonify({"ok": False, "error": "Acesso negado"}), 403

    # If changing own password, verify old password
    if is_self:
        if not _verify(old_password, target["hash"], target["salt"]):
            return jsonify({"ok": False, "error": "Senha atual incorreta"}), 400

    cfg = load_config()
    for o in cfg.get("owners", []):
        if o["id"] == oid:
            o["hash"], o["salt"] = _hash(new_password)
            save_config(cfg)
            return jsonify({"ok": True})

    return jsonify({"ok": False, "error": "Erro ao salvar"}), 500


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("DASHBOARD_PORT", 5500))
    print(f"\n{'='*50}")
    print(f"  HypeBot Dashboard")
    print(f"  http://localhost:{port}")
    print(f"{'='*50}\n")

    cfg = load_config()
    if not cfg.get("owners"):
        print("  ⚠️  Nenhum dono cadastrado.")
        print(f"  → Acesse http://localhost:{port}/setup para criar sua conta.\n")
    else:
        print(f"  Donos: {len(cfg['owners'])}")
        print(f"  Pressione Ctrl+C para parar.\n")

    app.run(host="0.0.0.0", port=port, debug=False)
